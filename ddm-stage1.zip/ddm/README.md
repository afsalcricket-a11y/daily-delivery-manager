# Daily Delivery Manager – Stage 1 (database + authentication)

1. Create a project at supabase.com.
2. SQL Editor → paste `supabase/schema.sql` → Run.
3. Authentication → URL Configuration: add your site URL (e.g. `http://localhost:5173/` and your GitHub Pages URL) to Site URL / Redirect URLs.
4. `cp .env.example .env` and fill in Project URL and anon key (Settings → API).
5. `npm install` then `npm run dev`.
6. Build: `npm run build`. GitHub Pages: set `VITE_BASE=/<repo>/` in `.env`, then `npm run deploy`.
