import { useEffect, useState } from 'react'
import { supabase, configured } from './supabase'
import Auth from './Auth.jsx'
import Deliveries from './Deliveries.jsx'
import Customers from './Customers.jsx'
import Products from './Products.jsx'
import Settings from './Settings.jsx'

const TABS = [
  { id: 'deliveries', label: 'Deliveries', icon: '🚚' },
  { id: 'customers', label: 'Customers', icon: '👥' },
  { id: 'products', label: 'Products', icon: '🥛' },
  { id: 'settings', label: 'Settings', icon: '⚙️' },
]

export default function App() {
  const [session, setSession] = useState(null)
  const [recovery, setRecovery] = useState(false)
  const [business, setBusiness] = useState(null)
  const [ready, setReady] = useState(false)
  const [tab, setTab] = useState('deliveries')

  useEffect(() => {
    if (!configured) { setReady(true); return }
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setReady(true) })
    const { data: sub } = supabase.auth.onAuthStateChange((event, s) => {
      setSession(s)
      if (event === 'PASSWORD_RECOVERY') setRecovery(true)
    })
    return () => sub.subscription.unsubscribe()
  }, [])

  async function loadBusiness() {
    const { data } = await supabase.from('businesses').select('*').eq('id', session.user.id).single()
    setBusiness(data)
  }
  useEffect(() => { if (session) loadBusiness(); else setBusiness(null) }, [session])

  if (!configured) {
    return (
      <main className="card narrow">
        <h1>Setup needed</h1>
        <p>Copy <code>.env.example</code> to <code>.env</code> and add your Supabase URL and anon key, then restart.</p>
      </main>
    )
  }
  if (!ready) return <p className="center">Loading…</p>
  if (!session || recovery) return <Auth recovery={recovery} onDone={() => setRecovery(false)} />

  return (
    <div className="shell">
      <header className="top"><strong>{business?.name || 'Daily Delivery Manager'}</strong></header>
      <main className="page">
        {tab === 'deliveries' && <Deliveries />}
        {tab === 'customers' && <Customers />}
        {tab === 'products' && <Products />}
        {tab === 'settings' && <Settings business={business} email={session.user.email} onSaved={loadBusiness} />}
      </main>
      <nav className="tabs">
        {TABS.map((t) => (
          <button key={t.id} className={tab === t.id ? 'on' : ''} onClick={() => setTab(t.id)}>
            <span aria-hidden="true">{t.icon}</span>{t.label}
          </button>
        ))}
      </nav>
    </div>
  )
}
