import { useEffect, useState } from 'react'
import { supabase, configured } from './supabase'
import Auth from './Auth.jsx'

export default function App() {
  const [session, setSession] = useState(null)
  const [recovery, setRecovery] = useState(false)
  const [business, setBusiness] = useState(null)
  const [ready, setReady] = useState(false)

  useEffect(() => {
    if (!configured) { setReady(true); return }
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setReady(true) })
    const { data: sub } = supabase.auth.onAuthStateChange((event, s) => {
      setSession(s)
      if (event === 'PASSWORD_RECOVERY') setRecovery(true)
    })
    return () => sub.subscription.unsubscribe()
  }, [])

  useEffect(() => {
    if (!session) { setBusiness(null); return }
    supabase.from('businesses').select('*').eq('id', session.user.id).single()
      .then(({ data }) => setBusiness(data))
  }, [session])

  if (!configured) {
    return (
      <main className="card narrow">
        <h1>Setup needed</h1>
        <p>Copy <code>.env.example</code> to <code>.env</code> and add your Supabase URL and anon key, then restart.</p>
      </main>
    )
  }
  if (!ready) return <p className="center">Loading…</p>
  if (!session || recovery) return <Auth recovery={recovery} onDone={() => setRecovery(false)} />

  return (
    <main className="card narrow">
      <h1>{business?.name || 'Daily Delivery Manager'}</h1>
      <p>You are signed in as {session.user.email}. Customers, deliveries, billing, payments and reports arrive in the next stages.</p>
      <button className="btn secondary" onClick={() => supabase.auth.signOut()}>Sign out</button>
    </main>
  )
}
