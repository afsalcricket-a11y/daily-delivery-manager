import { useState } from 'react'
import Products from './Products.jsx'
import Settings from './Settings.jsx'

export default function More({ business, email, onSaved }) {
  const [view, setView] = useState('products')
  return (
    <>
      <div className="seg">
        <button className={view === 'products' ? 'on' : ''} onClick={() => setView('products')}>Products</button>
        <button className={view === 'settings' ? 'on' : ''} onClick={() => setView('settings')}>Settings</button>
      </div>
      {view === 'products' ? <Products /> : <Settings business={business} email={email} onSaved={onSaved} />}
    </>
  )
}
